package com.example.grocery_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
